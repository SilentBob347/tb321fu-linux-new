#!/bin/sh
set -eu

LIBDIR=/usr/local/lib/y700-sns
ROOT=/usr/local/share/y700-sns/hexagonfs
PERSIST=/var/lib/y700-sns/persist
REGISTRY="$PERSIST/sensors/registry/registry"
LOGDIR=/var/log/y700-sns
LOG="$LOGDIR/hexagonrpcd-init.log"

mkdir -p "$REGISTRY" "$LOGDIR"

pre_count=$(find "$REGISTRY" -type f 2>/dev/null | wc -l)
if [ "$pre_count" -gt 0 ] && [ "$pre_count" -lt 200 ]; then
  echo "clearing partial registry_files=$pre_count before init" >>"$LOG"
  rm -rf "$PERSIST/sensors/registry"
  mkdir -p "$REGISTRY"
fi

waited=0
while [ ! -e /dev/fastrpc-adsp ] && [ "$waited" -lt 60 ]; do
  sleep 1
  waited=$((waited + 1))
done

if [ ! -e /dev/fastrpc-adsp ]; then
  echo "missing /dev/fastrpc-adsp after ${waited}s" >>"$LOG"
  exit 1
fi

tmp_log="$LOG.tmp"
rm -f "$tmp_log"

rc=0
timeout 45 env LD_LIBRARY_PATH="$LIBDIR" "$LIBDIR/hexagonrpcd" \
  -f /dev/fastrpc-adsp \
  -d adsp \
  -s \
  -R "$ROOT" \
  >"$tmp_log" 2>&1 || rc=$?

count=$(find "$REGISTRY" -type f 2>/dev/null | wc -l)

if [ "$count" -lt 200 ]; then
  cat "$tmp_log" >>"$LOG"
  echo "registry_files=$count hexagonrpcd_rc=$rc" >>"$LOG"
  rm -f "$tmp_log"
  exit 1
fi

rm -f "$tmp_log"
exit 0
