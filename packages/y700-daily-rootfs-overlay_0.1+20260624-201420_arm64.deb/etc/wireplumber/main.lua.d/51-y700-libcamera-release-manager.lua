-- Lenovo Y700 TB321FU: WirePlumber should publish standard libcamera source
-- nodes but should not keep its own libcamera device CameraManagers/SoftIPA
-- workers alive. PipeWire owns the actual streaming source nodes.

libcamera_monitor.properties["api.libcamera.enum.release-manager"] = "true"
libcamera_monitor.properties["api.libcamera.enum.direct-source-nodes"] = "true"
